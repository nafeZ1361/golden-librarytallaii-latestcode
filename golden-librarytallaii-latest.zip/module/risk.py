"""Pure risk and order validation for the trading engine."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class RiskLimits:
    max_volume: float = 1.0
    max_daily_loss: float = 0.0
    max_spread: float = 0.0
    max_open_positions: int = 0


@dataclass(frozen=True)
class RiskDecision:
    approved: bool
    reasons: tuple[str, ...] = ()


class RiskValidator:
    """Validates a proposed order without calling MT5 or a network service."""

    def __init__(self, limits: RiskLimits | None = None) -> None:
        self.limits = limits or RiskLimits()

    def validate(
        self,
        request: dict[str, Any],
        *,
        daily_profit: float = 0.0,
        open_positions: int = 0,
    ) -> RiskDecision:
        if request.get("risk_exempt") is True:
            return RiskDecision(approved=True)
        reasons: list[str] = []
        if not request.get("symbol"):
            reasons.append("symbol is required")
        volume = float(request.get("volume", 0) or 0)
        if volume <= 0:
            reasons.append("volume must be positive")
        if self.limits.max_volume > 0 and volume > self.limits.max_volume:
            reasons.append("volume exceeds max_volume")
        if self.limits.max_open_positions > 0 and open_positions >= self.limits.max_open_positions:
            reasons.append("max_open_positions reached")
        if self.limits.max_daily_loss > 0 and daily_profit <= -abs(self.limits.max_daily_loss):
            reasons.append("daily loss limit reached")

        spread = request.get("spread")
        if self.limits.max_spread > 0 and spread is not None and float(spread) > self.limits.max_spread:
            reasons.append("spread exceeds max_spread")

        order_type = str(request.get("order_type", "")).lower()
        price = request.get("price")
        sl = request.get("sl")
        tp = request.get("tp")
        if price is not None and sl is not None and tp is not None:
            price, sl, tp = float(price), float(sl), float(tp)
            if order_type in {"buy", "0"} and not (sl < price < tp):
                reasons.append("buy requires sl < price < tp")
            if order_type in {"sell", "1"} and not (tp < price < sl):
                reasons.append("sell requires tp < price < sl")

        return RiskDecision(approved=not reasons, reasons=tuple(reasons))
